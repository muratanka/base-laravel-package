<h1>Blog Theme 2</h1>
<p>Welcome to Theme 2</p>
<?php /**PATH D:\Herd\baselaravel11\Modules/Blog\Resources/views/themes/theme2/index.blade.php ENDPATH**/ ?>