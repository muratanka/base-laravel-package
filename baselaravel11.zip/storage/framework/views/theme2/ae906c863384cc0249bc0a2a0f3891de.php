<h1>Multisite Theme 2</h1>
<p>Welcome to Theme 2</p>
<?php /**PATH D:\Herd\baselaravel11\Modules/MultiSite\Resources/views/themes/theme2/index.blade.php ENDPATH**/ ?>