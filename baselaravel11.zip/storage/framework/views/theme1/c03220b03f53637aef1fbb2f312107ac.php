<h1>Multisite Theme 1</h1>
<p>Welcome to Theme 1</p>
<?php /**PATH D:\Herd\baselaravel11\Modules/MultiSite\Resources/views/themes/theme1/index.blade.php ENDPATH**/ ?>