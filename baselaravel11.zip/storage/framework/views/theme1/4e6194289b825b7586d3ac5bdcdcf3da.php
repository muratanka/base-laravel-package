<h1>News Theme 1</h1>
<p>Welcome to News Theme 1</p><?php /**PATH D:\Herd\baselaravel11\Modules/News\Resources/views/themes/theme1/index.blade.php ENDPATH**/ ?>