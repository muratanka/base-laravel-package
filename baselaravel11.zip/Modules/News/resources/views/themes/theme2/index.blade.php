<h1>News Theme 2</h1>
<p>Welcome to News Theme 2</p>