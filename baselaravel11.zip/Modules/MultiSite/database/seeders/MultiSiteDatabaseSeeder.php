<?php

namespace Modules\MultiSite\Database\Seeders;

use Illuminate\Database\Seeder;

class MultiSiteDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
