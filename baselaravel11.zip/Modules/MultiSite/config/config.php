<?php

return [
    'name' => 'MultiSite',
];
