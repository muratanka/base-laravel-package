<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
    1 => 'Modules\\MultiSite\\Providers\\MultiSiteServiceProvider',
    2 => 'Modules\\News\\Providers\\NewsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
    1 => 'Modules\\MultiSite\\Providers\\MultiSiteServiceProvider',
    2 => 'Modules\\News\\Providers\\NewsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);